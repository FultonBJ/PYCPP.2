#pragma once
class Display
{
public:
	void Menu();
};