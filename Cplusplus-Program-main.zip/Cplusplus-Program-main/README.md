# Cplusplus-Program

# Sumarize the problem and what problem it was solving
In this CS 210 course I had to write a C++ program with a menu that used functions written in an inbedded python program to analyze daily produce sales and rearrange the data in an organized and useful manner.

# What did you do particularly well?
looping through the list to increase the number of times an item was seen then writing each item only once with the occurance.

# Did you find writing any piece of this code challanging and how did you overcome this? What tools and/or resources are you adding to your support network? 
The challanging part of this project was not the coding but finding the correct versions of VS and python and placing the files in the correct places and in the right order so the program compiled correctly.

# what skills from this project will will be particularly transferable to other projects and/or course work?
Just having the python files in the C++ program will be useful in the future if I want to take advantage of the benefits each language provides.
